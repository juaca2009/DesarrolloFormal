#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM c2 */
	case 3: // STATE 1 - _spin_nvr.tmp:32 - [(!((ok==1)))] (6:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[12][1] = 1;
		if (!( !((((int)now.ok)==1))))
			continue;
		/* merge: assert(!(!((ok==1))))(0, 2, 6) */
		reached[12][2] = 1;
		spin_assert( !( !((((int)now.ok)==1))), " !( !((ok==1)))", II, tt, t);
		/* merge: .(goto)(0, 7, 6) */
		reached[12][7] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 4: // STATE 10 - _spin_nvr.tmp:37 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported10 = 0;
			if (verbose && !reported10)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported10 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported10 = 0;
			if (verbose && !reported10)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported10 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[12][10] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* CLAIM c11 */
	case 5: // STATE 1 - _spin_nvr.tmp:21 - [((!(!((piso_pedido[0]==1)))&&!((ascensor_pos==0))))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[11][1] = 1;
		if (!(( !( !((((int)now.piso_pedido[0])==1)))&& !((now.ascensor_pos==0)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 8 - _spin_nvr.tmp:26 - [(!((ascensor_pos==0)))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported8 = 0;
			if (verbose && !reported8)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported8 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported8 = 0;
			if (verbose && !reported8)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported8 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[11][8] = 1;
		if (!( !((now.ascensor_pos==0))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 13 - _spin_nvr.tmp:28 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported13 = 0;
			if (verbose && !reported13)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported13 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported13 = 0;
			if (verbose && !reported13)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported13 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[11][13] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* CLAIM p1 */
	case 8: // STATE 1 - _spin_nvr.tmp:15 - [(!((piso_pedido[2]==1)))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[10][1] = 1;
		if (!( !((((int)now.piso_pedido[2])==1))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 6 - _spin_nvr.tmp:17 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[10][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* CLAIM c1 */
	case 10: // STATE 1 - _spin_nvr.tmp:3 - [((!(!((piso_pedido[2]==1)))&&!((ascensor_pos==2))))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[9][1] = 1;
		if (!(( !( !((((int)now.piso_pedido[2])==1)))&& !((now.ascensor_pos==2)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 8 - _spin_nvr.tmp:8 - [(!((ascensor_pos==2)))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported8 = 0;
			if (verbose && !reported8)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported8 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported8 = 0;
			if (verbose && !reported8)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported8 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[9][8] = 1;
		if (!( !((now.ascensor_pos==2))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 13 - _spin_nvr.tmp:10 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported13 = 0;
			if (verbose && !reported13)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported13 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported13 = 0;
			if (verbose && !reported13)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported13 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[9][13] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 13: // STATE 1 - ascensor.pml:232 - [(run reloj1(ascensor_tiempo,ra))] (0:0:0 - 1)
		IfNotBlocked
		reached[8][1] = 1;
		if (!(addproc(II, 1, 0, ((int)now.ascensor_tiempo), now.ra)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 2 - ascensor.pml:232 - [(run reloj2(puerta_tiempo,rc))] (0:0:0 - 1)
		IfNotBlocked
		reached[8][2] = 1;
		if (!(addproc(II, 1, 1, ((int)now.puerta_tiempo), now.rc)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 3 - ascensor.pml:232 - [(run MonitorReloj())] (0:0:0 - 1)
		IfNotBlocked
		reached[8][3] = 1;
		if (!(addproc(II, 1, 2, 0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 4 - ascensor.pml:233 - [(run ascensor())] (0:0:0 - 1)
		IfNotBlocked
		reached[8][4] = 1;
		if (!(addproc(II, 1, 3, 0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 5 - ascensor.pml:233 - [(run piso(2))] (0:0:0 - 1)
		IfNotBlocked
		reached[8][5] = 1;
		if (!(addproc(II, 1, 4, 2, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 6 - ascensor.pml:233 - [(run piso(1))] (0:0:0 - 1)
		IfNotBlocked
		reached[8][6] = 1;
		if (!(addproc(II, 1, 4, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 7 - ascensor.pml:233 - [(run piso(0))] (0:0:0 - 1)
		IfNotBlocked
		reached[8][7] = 1;
		if (!(addproc(II, 1, 4, 0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 8 - ascensor.pml:233 - [(run controlador())] (0:0:0 - 1)
		IfNotBlocked
		reached[8][8] = 1;
		if (!(addproc(II, 1, 5, 0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 9 - ascensor.pml:233 - [(run inv())] (0:0:0 - 1)
		IfNotBlocked
		reached[8][9] = 1;
		if (!(addproc(II, 1, 6, 0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 10 - ascensor.pml:233 - [(run inv2())] (0:0:0 - 1)
		IfNotBlocked
		reached[8][10] = 1;
		if (!(addproc(II, 1, 7, 0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 12 - ascensor.pml:234 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[8][12] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC inv2 */
	case 24: // STATE 1 - ascensor.pml:219 - [assert(((ascensor_pos>=0)&&(ascensor_pos<3)))] (0:0:0 - 1)
		IfNotBlocked
		reached[7][1] = 1;
		spin_assert(((now.ascensor_pos>=0)&&(now.ascensor_pos<3)), "((ascensor_pos>=0)&&(ascensor_pos<3))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 2 - ascensor.pml:220 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[7][2] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC inv */
	case 26: // STATE 1 - ascensor.pml:213 - [assert(!(((ascensor_abierta==1)&&(ascensor_parado==0))))] (0:0:0 - 1)
		IfNotBlocked
		reached[6][1] = 1;
		spin_assert( !(((((int)now.ascensor_abierta)==1)&&(((int)now.ascensor_parado)==0))), " !(((ascensor_abierta==1)&&(ascensor_parado==0)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 27: // STATE 2 - ascensor.pml:215 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[6][2] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC controlador */
	case 28: // STATE 1 - ascensor.pml:160 - [cla!listo] (0:0:0 - 1)
		IfNotBlocked
		reached[5][1] = 1;
		if (q_full(now.cla))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.cla);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.cla, 0, 2, 1);
		if (q_zero(now.cla)) { boq = now.cla; };
		_m = 2; goto P999; /* 0 */
	case 29: // STATE 2 - ascensor.pml:163 - [cla?listo] (0:0:0 - 1)
		reached[5][2] = 1;
		if (q_zero(now.cla))
		{	if (boq != now.cla) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(now.cla) == 0) continue;

		XX=1;
		if (2 != qrecv(now.cla, 0, 0, 0)) continue;
		
#ifndef BFS_PAR
		if (q_flds[((Q0 *)qptr(now.cla-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
#endif
		;
		qrecv(now.cla, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.cla);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.cla))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 30: // STATE 3 - ascensor.pml:165 - [((destino<3))] (0:0:0 - 1)
		IfNotBlocked
		reached[5][3] = 1;
		if (!((((P5 *)_this)->destino<3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 4 - ascensor.pml:167 - [((piso_pedido[destino]==1))] (0:0:0 - 1)
		IfNotBlocked
		reached[5][4] = 1;
		if (!((((int)now.piso_pedido[ Index(((P5 *)_this)->destino, 3) ])==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 7 - ascensor.pml:168 - [(1)] (13:0:1 - 1)
		IfNotBlocked
		reached[5][7] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(13, 9, 13) */
		reached[5][9] = 1;
		;
		/* merge: destino = (destino+1)(13, 10, 13) */
		reached[5][10] = 1;
		(trpt+1)->bup.oval = ((P5 *)_this)->destino;
		((P5 *)_this)->destino = (((P5 *)_this)->destino+1);
#ifdef VAR_RANGES
		logval("controlador:destino", ((P5 *)_this)->destino);
#endif
		;
		/* merge: .(goto)(0, 14, 13) */
		reached[5][14] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 33: // STATE 10 - ascensor.pml:170 - [destino = (destino+1)] (0:13:1 - 2)
		IfNotBlocked
		reached[5][10] = 1;
		(trpt+1)->bup.oval = ((P5 *)_this)->destino;
		((P5 *)_this)->destino = (((P5 *)_this)->destino+1);
#ifdef VAR_RANGES
		logval("controlador:destino", ((P5 *)_this)->destino);
#endif
		;
		/* merge: .(goto)(0, 14, 13) */
		reached[5][14] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 34: // STATE 11 - ascensor.pml:171 - [((destino>=3))] (0:0:0 - 1)
		IfNotBlocked
		reached[5][11] = 1;
		if (!((((P5 *)_this)->destino>=3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 35: // STATE 16 - ascensor.pml:175 - [((destino<3))] (0:0:0 - 1)
		IfNotBlocked
		reached[5][16] = 1;
		if (!((((P5 *)_this)->destino<3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 36: // STATE 17 - ascensor.pml:176 - [((destino==ascensor_pos))] (0:0:0 - 1)
		IfNotBlocked
		reached[5][17] = 1;
		if (!((((P5 *)_this)->destino==now.ascensor_pos)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 37: // STATE 18 - ascensor.pml:177 - [rc!start] (0:0:0 - 1)
		IfNotBlocked
		reached[5][18] = 1;
		if (q_full(now.rc))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.rc);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.rc, 0, 3, 1);
		if (q_zero(now.rc)) { boq = now.rc; };
		_m = 2; goto P999; /* 0 */
	case 38: // STATE 19 - ascensor.pml:178 - [rc?ring] (0:0:0 - 1)
		reached[5][19] = 1;
		if (q_zero(now.rc))
		{	if (boq != now.rc) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(now.rc) == 0) continue;

		XX=1;
		if (4 != qrecv(now.rc, 0, 0, 0)) continue;
		
#ifndef BFS_PAR
		if (q_flds[((Q0 *)qptr(now.rc-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
#endif
		;
		qrecv(now.rc, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.rc);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.rc))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 39: // STATE 20 - ascensor.pml:179 - [ascensor_abierta = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[5][20] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_abierta);
		now.ascensor_abierta = 1;
#ifdef VAR_RANGES
		logval("ascensor_abierta", ((int)now.ascensor_abierta));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 25 - ascensor.pml:182 - [rc!start] (0:0:0 - 3)
		IfNotBlocked
		reached[5][25] = 1;
		if (q_full(now.rc))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.rc);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.rc, 0, 3, 1);
		if (q_zero(now.rc)) { boq = now.rc; };
		_m = 2; goto P999; /* 0 */
	case 41: // STATE 26 - ascensor.pml:183 - [rc?ring] (0:0:0 - 1)
		reached[5][26] = 1;
		if (q_zero(now.rc))
		{	if (boq != now.rc) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(now.rc) == 0) continue;

		XX=1;
		if (4 != qrecv(now.rc, 0, 0, 0)) continue;
		
#ifndef BFS_PAR
		if (q_flds[((Q0 *)qptr(now.rc-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
#endif
		;
		qrecv(now.rc, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.rc);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.rc))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 42: // STATE 27 - ascensor.pml:184 - [ascensor_abierta = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[5][27] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_abierta);
		now.ascensor_abierta = 0;
#ifdef VAR_RANGES
		logval("ascensor_abierta", ((int)now.ascensor_abierta));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 32 - ascensor.pml:188 - [piso_pedido[destino] = 0] (0:0:1 - 3)
		IfNotBlocked
		reached[5][32] = 1;
		(trpt+1)->bup.oval = ((int)now.piso_pedido[ Index(((P5 *)_this)->destino, 3) ]);
		now.piso_pedido[ Index(((P5 *)_this)->destino, 3) ] = 0;
#ifdef VAR_RANGES
		logval("piso_pedido[controlador:destino]", ((int)now.piso_pedido[ Index(((P5 *)_this)->destino, 3) ]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 33 - ascensor.pml:190 - [cla!listo] (0:0:0 - 1)
		IfNotBlocked
		reached[5][33] = 1;
		if (q_full(now.cla))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.cla);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.cla, 0, 2, 1);
		if (q_zero(now.cla)) { boq = now.cla; };
		_m = 2; goto P999; /* 0 */
	case 45: // STATE 34 - ascensor.pml:192 - [((destino>ascensor_pos))] (0:0:0 - 1)
		IfNotBlocked
		reached[5][34] = 1;
		if (!((((P5 *)_this)->destino>now.ascensor_pos)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 46: // STATE 35 - ascensor.pml:193 - [ascensor_sube = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[5][35] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_sube);
		now.ascensor_sube = 1;
#ifdef VAR_RANGES
		logval("ascensor_sube", ((int)now.ascensor_sube));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 47: // STATE 36 - ascensor.pml:194 - [cla!mover] (0:0:0 - 1)
		IfNotBlocked
		reached[5][36] = 1;
		if (q_full(now.cla))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.cla);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.cla, 0, 1, 1);
		if (q_zero(now.cla)) { boq = now.cla; };
		_m = 2; goto P999; /* 0 */
	case 48: // STATE 37 - ascensor.pml:195 - [((destino<ascensor_pos))] (0:0:0 - 1)
		IfNotBlocked
		reached[5][37] = 1;
		if (!((((P5 *)_this)->destino<now.ascensor_pos)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 49: // STATE 38 - ascensor.pml:196 - [ascensor_sube = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[5][38] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_sube);
		now.ascensor_sube = 0;
#ifdef VAR_RANGES
		logval("ascensor_sube", ((int)now.ascensor_sube));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 50: // STATE 39 - ascensor.pml:197 - [cla!mover] (0:0:0 - 1)
		IfNotBlocked
		reached[5][39] = 1;
		if (q_full(now.cla))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.cla);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.cla, 0, 1, 1);
		if (q_zero(now.cla)) { boq = now.cla; };
		_m = 2; goto P999; /* 0 */
	case 51: // STATE 43 - ascensor.pml:201 - [destino = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[5][43] = 1;
		(trpt+1)->bup.oval = ((P5 *)_this)->destino;
		((P5 *)_this)->destino = 0;
#ifdef VAR_RANGES
		logval("controlador:destino", ((P5 *)_this)->destino);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 52: // STATE 44 - ascensor.pml:202 - [cla!listo] (0:0:0 - 1)
		IfNotBlocked
		reached[5][44] = 1;
		if (q_full(now.cla))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.cla);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.cla, 0, 2, 1);
		if (q_zero(now.cla)) { boq = now.cla; };
		_m = 2; goto P999; /* 0 */
	case 53: // STATE 50 - ascensor.pml:209 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[5][50] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC piso */
	case 54: // STATE 1 - ascensor.pml:149 - [piso_pedido[pos] = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[4][1] = 1;
		(trpt+1)->bup.oval = ((int)now.piso_pedido[ Index(((P4 *)_this)->pos, 3) ]);
		now.piso_pedido[ Index(((P4 *)_this)->pos, 3) ] = 0;
#ifdef VAR_RANGES
		logval("piso_pedido[piso:pos]", ((int)now.piso_pedido[ Index(((P4 *)_this)->pos, 3) ]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 55: // STATE 2 - ascensor.pml:150 - [((!(piso_pedido[pos])&&(ascensor_pos!=pos)))] (0:0:0 - 1)
		IfNotBlocked
		reached[4][2] = 1;
		if (!(( !(((int)now.piso_pedido[ Index(((P4 *)_this)->pos, 3) ]))&&(now.ascensor_pos!=((P4 *)_this)->pos))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 56: // STATE 3 - ascensor.pml:151 - [printf('Llamado en piso %d\\n',pos)] (0:0:0 - 1)
		IfNotBlocked
		reached[4][3] = 1;
		Printf("Llamado en piso %d\n", ((P4 *)_this)->pos);
		_m = 3; goto P999; /* 0 */
	case 57: // STATE 4 - ascensor.pml:152 - [piso_pedido[pos] = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[4][4] = 1;
		(trpt+1)->bup.oval = ((int)now.piso_pedido[ Index(((P4 *)_this)->pos, 3) ]);
		now.piso_pedido[ Index(((P4 *)_this)->pos, 3) ] = 1;
#ifdef VAR_RANGES
		logval("piso_pedido[piso:pos]", ((int)now.piso_pedido[ Index(((P4 *)_this)->pos, 3) ]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 58: // STATE 8 - ascensor.pml:155 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[4][8] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC ascensor */
	case 59: // STATE 1 - ascensor.pml:105 - [ascensor_pos = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.oval = now.ascensor_pos;
		now.ascensor_pos = 0;
#ifdef VAR_RANGES
		logval("ascensor_pos", now.ascensor_pos);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 60: // STATE 2 - ascensor.pml:106 - [ascensor_parado = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][2] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_parado);
		now.ascensor_parado = 1;
#ifdef VAR_RANGES
		logval("ascensor_parado", ((int)now.ascensor_parado));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 61: // STATE 3 - ascensor.pml:107 - [ascensor_sube = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][3] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_sube);
		now.ascensor_sube = 1;
#ifdef VAR_RANGES
		logval("ascensor_sube", ((int)now.ascensor_sube));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 62: // STATE 4 - ascensor.pml:108 - [ascensor_abierta = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[3][4] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_abierta);
		now.ascensor_abierta = 0;
#ifdef VAR_RANGES
		logval("ascensor_abierta", ((int)now.ascensor_abierta));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 63: // STATE 5 - ascensor.pml:110 - [cla?mover] (0:0:0 - 1)
		reached[3][5] = 1;
		if (q_zero(now.cla))
		{	if (boq != now.cla) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(now.cla) == 0) continue;

		XX=1;
		if (1 != qrecv(now.cla, 0, 0, 0)) continue;
		
#ifndef BFS_PAR
		if (q_flds[((Q0 *)qptr(now.cla-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
#endif
		;
		qrecv(now.cla, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.cla);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.cla))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 64: // STATE 6 - ascensor.pml:110 - [ok = ((ascensor_pos>=0)&&(ascensor_pos<3))] (0:0:1 - 1)
		IfNotBlocked
		reached[3][6] = 1;
		(trpt+1)->bup.oval = ((int)now.ok);
		now.ok = ((now.ascensor_pos>=0)&&(now.ascensor_pos<3));
#ifdef VAR_RANGES
		logval("ok", ((int)now.ok));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 65: // STATE 7 - ascensor.pml:111 - [((((ascensor_pos+1)<3)&&(ascensor_sube==1)))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][7] = 1;
		if (!((((now.ascensor_pos+1)<3)&&(((int)now.ascensor_sube)==1))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 66: // STATE 8 - ascensor.pml:112 - [ra!start] (0:0:0 - 1)
		IfNotBlocked
		reached[3][8] = 1;
		if (q_full(now.ra))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.ra);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.ra, 0, 3, 1);
		if (q_zero(now.ra)) { boq = now.ra; };
		_m = 2; goto P999; /* 0 */
	case 67: // STATE 9 - ascensor.pml:112 - [ascensor_parado = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[3][9] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_parado);
		now.ascensor_parado = 0;
#ifdef VAR_RANGES
		logval("ascensor_parado", ((int)now.ascensor_parado));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 68: // STATE 11 - ascensor.pml:113 - [ra?ring] (0:0:0 - 1)
		reached[3][11] = 1;
		if (q_zero(now.ra))
		{	if (boq != now.ra) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(now.ra) == 0) continue;

		XX=1;
		if (4 != qrecv(now.ra, 0, 0, 0)) continue;
		
#ifndef BFS_PAR
		if (q_flds[((Q0 *)qptr(now.ra-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
#endif
		;
		qrecv(now.ra, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.ra);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.ra))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 69: // STATE 12 - ascensor.pml:114 - [cla!listo] (0:0:0 - 1)
		IfNotBlocked
		reached[3][12] = 1;
		if (q_full(now.cla))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.cla);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.cla, 0, 2, 1);
		if (q_zero(now.cla)) { boq = now.cla; };
		_m = 2; goto P999; /* 0 */
	case 70: // STATE 13 - ascensor.pml:114 - [ascensor_pos = (ascensor_pos+1)] (0:35:2 - 1)
		IfNotBlocked
		reached[3][13] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.ascensor_pos;
		now.ascensor_pos = (now.ascensor_pos+1);
#ifdef VAR_RANGES
		logval("ascensor_pos", now.ascensor_pos);
#endif
		;
		/* merge: ascensor_parado = 1(35, 14, 35) */
		reached[3][14] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.ascensor_parado);
		now.ascensor_parado = 1;
#ifdef VAR_RANGES
		logval("ascensor_parado", ((int)now.ascensor_parado));
#endif
		;
		/* merge: goto :b6(35, 15, 35) */
		reached[3][15] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 71: // STATE 20 - ascensor.pml:118 - [(((ascensor_pos>0)&&(ascensor_sube==0)))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][20] = 1;
		if (!(((now.ascensor_pos>0)&&(((int)now.ascensor_sube)==0))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 72: // STATE 21 - ascensor.pml:119 - [ra!start] (0:0:0 - 1)
		IfNotBlocked
		reached[3][21] = 1;
		if (q_full(now.ra))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.ra);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.ra, 0, 3, 1);
		if (q_zero(now.ra)) { boq = now.ra; };
		_m = 2; goto P999; /* 0 */
	case 73: // STATE 22 - ascensor.pml:119 - [ascensor_parado = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[3][22] = 1;
		(trpt+1)->bup.oval = ((int)now.ascensor_parado);
		now.ascensor_parado = 0;
#ifdef VAR_RANGES
		logval("ascensor_parado", ((int)now.ascensor_parado));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 74: // STATE 24 - ascensor.pml:120 - [ra?ring] (0:0:0 - 1)
		reached[3][24] = 1;
		if (q_zero(now.ra))
		{	if (boq != now.ra) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(now.ra) == 0) continue;

		XX=1;
		if (4 != qrecv(now.ra, 0, 0, 0)) continue;
		
#ifndef BFS_PAR
		if (q_flds[((Q0 *)qptr(now.ra-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
#endif
		;
		qrecv(now.ra, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.ra);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.ra))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 75: // STATE 25 - ascensor.pml:121 - [cla!listo] (0:0:0 - 1)
		IfNotBlocked
		reached[3][25] = 1;
		if (q_full(now.cla))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.cla);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.cla, 0, 2, 1);
		if (q_zero(now.cla)) { boq = now.cla; };
		_m = 2; goto P999; /* 0 */
	case 76: // STATE 26 - ascensor.pml:121 - [ascensor_pos = (ascensor_pos-1)] (0:35:2 - 1)
		IfNotBlocked
		reached[3][26] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.ascensor_pos;
		now.ascensor_pos = (now.ascensor_pos-1);
#ifdef VAR_RANGES
		logval("ascensor_pos", now.ascensor_pos);
#endif
		;
		/* merge: ascensor_parado = 1(35, 27, 35) */
		reached[3][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.ascensor_parado);
		now.ascensor_parado = 1;
#ifdef VAR_RANGES
		logval("ascensor_parado", ((int)now.ascensor_parado));
#endif
		;
		/* merge: goto :b7(35, 28, 35) */
		reached[3][28] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 77: // STATE 38 - ascensor.pml:143 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[3][38] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC MonitorReloj */
	case 78: // STATE 1 - ascensor.pml:71 - [(timeout)] (0:0:0 - 1)
		IfNotBlocked
		reached[2][1] = 1;
		if (!(((trpt->tau)&1)))
			continue;
		_m = 1; goto P999; /* 0 */
	case 79: // STATE 2 - ascensor.pml:72 - [((tictac1<60))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][2] = 1;
		if (!((((int)now.tictac1)<60)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 80: // STATE 3 - ascensor.pml:73 - [tictac1 = (tictac1+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[2][3] = 1;
		(trpt+1)->bup.oval = ((int)now.tictac1);
		now.tictac1 = (((int)now.tictac1)+1);
#ifdef VAR_RANGES
		logval("tictac1", ((int)now.tictac1));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 81: // STATE 4 - ascensor.pml:74 - [((tictac1>=60))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][4] = 1;
		if (!((((int)now.tictac1)>=60)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 82: // STATE 5 - ascensor.pml:74 - [tictac1 = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[2][5] = 1;
		(trpt+1)->bup.oval = ((int)now.tictac1);
		now.tictac1 = 0;
#ifdef VAR_RANGES
		logval("tictac1", ((int)now.tictac1));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 83: // STATE 8 - ascensor.pml:77 - [((tictac2<60))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][8] = 1;
		if (!((((int)now.tictac2)<60)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 84: // STATE 9 - ascensor.pml:78 - [tictac2 = (tictac2+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[2][9] = 1;
		(trpt+1)->bup.oval = ((int)now.tictac2);
		now.tictac2 = (((int)now.tictac2)+1);
#ifdef VAR_RANGES
		logval("tictac2", ((int)now.tictac2));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 85: // STATE 10 - ascensor.pml:79 - [((tictac2>=60))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][10] = 1;
		if (!((((int)now.tictac2)>=60)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 86: // STATE 11 - ascensor.pml:79 - [tictac2 = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[2][11] = 1;
		(trpt+1)->bup.oval = ((int)now.tictac2);
		now.tictac2 = 0;
#ifdef VAR_RANGES
		logval("tictac2", ((int)now.tictac2));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 87: // STATE 17 - ascensor.pml:82 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[2][17] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC reloj2 */
	case 88: // STATE 1 - ascensor.pml:51 - [alarma2 = espera] (0:0:1 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		(trpt+1)->bup.oval = ((int)now.alarma2);
		now.alarma2 = ((int)((P1 *)_this)->espera);
#ifdef VAR_RANGES
		logval("alarma2", ((int)now.alarma2));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 89: // STATE 2 - ascensor.pml:52 - [canal?start] (0:0:0 - 1)
		reached[1][2] = 1;
		if (q_zero(((P1 *)_this)->canal))
		{	if (boq != ((P1 *)_this)->canal) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P1 *)_this)->canal) == 0) continue;

		XX=1;
		if (3 != qrecv(((P1 *)_this)->canal, 0, 0, 0)) continue;
		
#ifndef BFS_PAR
		if (q_flds[((Q0 *)qptr(((P1 *)_this)->canal-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
#endif
		;
		qrecv(((P1 *)_this)->canal, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P1 *)_this)->canal);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		if (q_zero(((P1 *)_this)->canal))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 90: // STATE 3 - ascensor.pml:52 - [alarma2 = (tictac2+espera)] (0:0:1 - 1)
		IfNotBlocked
		reached[1][3] = 1;
		(trpt+1)->bup.oval = ((int)now.alarma2);
		now.alarma2 = (((int)now.tictac2)+((int)((P1 *)_this)->espera));
#ifdef VAR_RANGES
		logval("alarma2", ((int)now.alarma2));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 91: // STATE 4 - ascensor.pml:53 - [((alarma2<60))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][4] = 1;
		if (!((((int)now.alarma2)<60)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 92: // STATE 5 - ascensor.pml:54 - [((tictac2==alarma2))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][5] = 1;
		if (!((((int)now.tictac2)==((int)now.alarma2))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 93: // STATE 6 - ascensor.pml:55 - [canal!ring] (0:0:0 - 1)
		IfNotBlocked
		reached[1][6] = 1;
		if (q_full(((P1 *)_this)->canal))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->canal);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->canal, 0, 4, 1);
		if (q_zero(((P1 *)_this)->canal)) { boq = ((P1 *)_this)->canal; };
		_m = 2; goto P999; /* 0 */
	case 94: // STATE 9 - ascensor.pml:58 - [((alarma2>=60))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][9] = 1;
		if (!((((int)now.alarma2)>=60)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 95: // STATE 10 - ascensor.pml:59 - [alarma2 = espera] (0:0:1 - 1)
		IfNotBlocked
		reached[1][10] = 1;
		(trpt+1)->bup.oval = ((int)now.alarma2);
		now.alarma2 = ((int)((P1 *)_this)->espera);
#ifdef VAR_RANGES
		logval("alarma2", ((int)now.alarma2));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 96: // STATE 11 - ascensor.pml:60 - [((tictac2!=alarma2))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][11] = 1;
		if (!((((int)now.tictac2)!=((int)now.alarma2))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 97: // STATE 18 - ascensor.pml:66 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[1][18] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC reloj1 */
	case 98: // STATE 1 - ascensor.pml:31 - [alarma1 = espera] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.alarma1);
		now.alarma1 = ((int)((P0 *)_this)->espera);
#ifdef VAR_RANGES
		logval("alarma1", ((int)now.alarma1));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 99: // STATE 2 - ascensor.pml:32 - [canal?start] (0:0:0 - 1)
		reached[0][2] = 1;
		if (q_zero(((P0 *)_this)->canal))
		{	if (boq != ((P0 *)_this)->canal) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P0 *)_this)->canal) == 0) continue;

		XX=1;
		if (3 != qrecv(((P0 *)_this)->canal, 0, 0, 0)) continue;
		
#ifndef BFS_PAR
		if (q_flds[((Q0 *)qptr(((P0 *)_this)->canal-1))->_t] != 1)
			Uerror("wrong nr of msg fields in rcv");
#endif
		;
		qrecv(((P0 *)_this)->canal, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P0 *)_this)->canal);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		if (q_zero(((P0 *)_this)->canal))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 100: // STATE 3 - ascensor.pml:32 - [alarma1 = (tictac1+espera)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		(trpt+1)->bup.oval = ((int)now.alarma1);
		now.alarma1 = (((int)now.tictac1)+((int)((P0 *)_this)->espera));
#ifdef VAR_RANGES
		logval("alarma1", ((int)now.alarma1));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 101: // STATE 4 - ascensor.pml:33 - [((alarma1<60))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][4] = 1;
		if (!((((int)now.alarma1)<60)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 102: // STATE 5 - ascensor.pml:34 - [((tictac1==alarma1))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][5] = 1;
		if (!((((int)now.tictac1)==((int)now.alarma1))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 103: // STATE 6 - ascensor.pml:35 - [canal!ring] (0:0:0 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		if (q_full(((P0 *)_this)->canal))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P0 *)_this)->canal);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P0 *)_this)->canal, 0, 4, 1);
		if (q_zero(((P0 *)_this)->canal)) { boq = ((P0 *)_this)->canal; };
		_m = 2; goto P999; /* 0 */
	case 104: // STATE 9 - ascensor.pml:38 - [((alarma1>=60))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][9] = 1;
		if (!((((int)now.alarma1)>=60)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 105: // STATE 10 - ascensor.pml:39 - [alarma1 = espera] (0:0:1 - 1)
		IfNotBlocked
		reached[0][10] = 1;
		(trpt+1)->bup.oval = ((int)now.alarma1);
		now.alarma1 = ((int)((P0 *)_this)->espera);
#ifdef VAR_RANGES
		logval("alarma1", ((int)now.alarma1));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 106: // STATE 11 - ascensor.pml:40 - [((tictac1!=alarma1))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][11] = 1;
		if (!((((int)now.tictac1)!=((int)now.alarma1))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 107: // STATE 18 - ascensor.pml:46 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][18] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

